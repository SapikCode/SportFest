

const express = require('express');
const { connectToDatabase } = require('./utils/db.ts');
const cors = require('cors');
const port = 2000;
const app = express();

app.use(cors({
  origin: 'http://localhost:3000'
}));

app.use(express.json());

app.get('/chart',async (req,res)=>{
  try{
    const dbcon = await connectToDatabase();
    dbcon.query('SELECT * FROM test;',(error,result)=>{
      if (error){
        throw error
      }
    res.status(200).json({data : result});
    })
  }
  catch (error){
    console.log('error karna',error)
  }
})








app.listen(port,()=>{
  console.log('server berjalan')
});