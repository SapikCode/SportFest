

require('dotenv').config();
const { connectToDatabase } = require('./utils/db.ts')
const express = require('express');
const app = express();
const port = 2000;
const cors = require('cors');
app.use(cors({
  origin: 'http://localhost:3000'
}));



app.use(express.json());


app.get('/', (req, res) => {
  res.send('Hello, World!');
});

app.get('/atlet', async (req,res)=>{
    try {
        const dbConnection = await connectToDatabase();
        dbConnection.query('SELECT * FROM data_customer;', (error, results) => {
          if (error) {
            throw error;
          }
          res.json(results);
        });
      } catch (error) {
        console.error('Error fetching data:', error);
        res.status(500).json({ error: 'Internal Server Error' });
      }
})




// Menjalankan server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}/`);
});
