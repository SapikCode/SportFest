// /utils/db.ts

const mysql = require('mysql');

const pool = mysql.createPool({
  connectionLimit: 10, // Sesuaikan dengan kebutuhan Anda
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'sportfestdb',
});

function connectToDatabase() {
  return new Promise((resolve, reject) => {
    pool.getConnection((error, connection) => {
      if (error) {
        reject(error);
        return;
      }
      console.log('Connected to MySQL database');
      resolve(connection);

      // Pastikan koneksi dilepaskan kembali ke pool setelah selesai
      connection.release();
    });
  });
}

module.exports = { connectToDatabase };
