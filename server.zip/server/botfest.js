
require('dotenv').config();
const Groq = require('groq-sdk')
const express = require('express')
const port = 2000
const cors = require('cors');
const app = express()
const { connectToDatabase } = require('./utils/db.ts')

app.use(cors({
    origin: 'http://localhost:3000'
  }));
  
app.use(express.json())

const kunciapi = process.env.GROQ_API_KEY;

var atlet = []

const groq = new Groq({ apiKey: kunciapi});
app.get('/botfest', async (req,res)=>{
  const { pertanyaan } = (req.query)
  const { validation } = (req.query)
  if (validation == "Tunggal Putra"){
    atlet = await getAtlet()
  }else if (validation == "Tunggal Putri"){
    atlet = await getTunggalPutri()
  }else if ( validation == "Kejuaraan"){
    atlet = await getData()
  }else if ( validation == "Prestasi"){
    atlet = await getPrestasi()
  }else if (validation == "General"){
    atlet = "Jawab Sesuai Kemampuan Anda"
  }
  const chatCompletion = await getGroqChatCompletion(pertanyaan,atlet);
  const hasil = chatCompletion.choices[0]?.message?.content || ""
  res.status(200).json(hasil);
})

async function getGroqChatCompletion(ask,atlet) {
  return groq.chat.completions.create({
      messages: [
          {
              role: "user",
              content: `Saya memiliki sebuah pertanyaan: "${ask}".  ini datanya : ${JSON.stringify(atlet)}`,
          },
          {
              role: "system",
              content: `Anda adalah asisten yang ahli dalam memberikan jawaban yang relevan dan sesuai dengan konteks pertanyaan yang diberikan. Pastikan jawaban Anda data atlet yang disediakan untuk memberikan jawaban yang singkat to the point jika pertanyaan diluar data atlet atau topik lain anda harus menjawabnya dengan kemampuan anda ,ingat anda adalah ahli di bidang bulu tangkis, GUNAKAN BAHASA INDONESIA`
          }
      ],
      model: "llama3-8b-8192",
      temperature: 0.8,
      max_tokens: 10000,
  });
}

async function getAtlet(){
  const dbconn = await connectToDatabase();
  return new Promise((resolve,reject)=>{
    dbconn.query("SELECT a.ID,a.NAMA, a.POSISI,b.PERINGKAT, b.MINGGU, b.POINT FROM klasemenbwf b JOIN atlet a ON b.ATLET_ID = a.ID WHERE a.POSISI = 'Tunggal Putra' ORDER BY a.ID ASC, b.MINGGU DESC, b.POINT DESC;",(error,result)=>{
      if (error){
        throw reject(error)
      }
      resolve(result)
    })
  })
}
async function getTunggalPutri(){
  const dbconn = await connectToDatabase();
  return new Promise((resolve,reject)=>{
    dbconn.query("SELECT a.ID,a.NAMA, a.POSISI,b.PERINGKAT, b.MINGGU, b.POINT FROM klasemenbwf b JOIN atlet a ON b.ATLET_ID = a.ID WHERE a.POSISI = 'Tunggal Putri' ORDER BY a.ID ASC, b.MINGGU DESC, b.POINT DESC;",(error,result)=>{
      if (error){
        throw reject(error)
      }
      resolve(result)
    })
  })
}




async function getData(){
  const dbconn = await connectToDatabase()
  return new Promise((resolve,reject)=>{
    dbconn.query('SELECT * FROM kejuaraan;',(error,result)=>{
      if (error){
        reject(error)
      }
      resolve(result)
    })
  })
}

app.get('/carikejuaraan', async (req, res) => {
  const { search } = (req.query);
  const dbcon = await connectToDatabase();
  dbcon.query(`SELECT * FROM kejuaraan WHERE NAMA LIKE '%${search}%';`,(error,result)=>{
    if (error){
      throw error
    }
    res.status(200).json({data : result})
  })
})


app.get('/kejuaraan', async(req,res)=>{
  const dbconn = await connectToDatabase()
  dbconn.query('SELECT * FROM kejuaraan;',(error,result)=>{
    if(error){
      throw error
    }
  res.status(200).json({data : result})
  })
})

app.get('/bulankejuaraan', async (req,res)=>{
  const { bulan } = (req.query)
  const dbconn = await connectToDatabase();
  dbconn.query(`SELECT * FROM kejuaraan WHERE BULAN = '${bulan}';`,(error,result)=>{
    if (error){
      throw error
    }
    res.status(200).json({data : result})
  })
  
})


app.get('/klasemenbwf', async (req,res)=>{
  let terbaru = ""
  const { posisi } = (req.query)
  const { week } = (req.query)
  const minggu = parseInt(week)
  const { tertinggi } = (req.query)
  if (tertinggi.length>= 9){
    terbaru = "DESC"
  }else{
    terbaru = "ASC"
  }
  const dbconn = await connectToDatabase()
  dbconn.query(`SELECT a.ID,a.NAMA, a.POSISI, b.MINGGU, b.TOURNAMENT, b.POINT, ROW_NUMBER() OVER (ORDER BY b.POINT DESC) AS URUTAN FROM klasemenbwf b JOIN atlet a ON b.ATLET_ID = a.ID WHERE a.POSISI = '${posisi}' AND b.MINGGU = ${minggu} ORDER BY b.POINT ${terbaru};
`,(error,result)=>{
  if (error){
    throw error
  }
  res.status(200).json({data : result})
})
})

app.get('/statistikatlet', async (req,res)=>{
  const { atletid } = (req.query)
  const dbcon = await connectToDatabase()
  dbcon.query(`SELECT * FROM klasemenbwf WHERE ATLET_ID = ${atletid} ORDER BY MINGGU ASC`,(error,result)=>{
    if (error){
      throw error
    }
    res.status(200).json({data : result})
  })
})


app.get('/atletstat',async(req,res)=>{
  const { id } = (req.query)
  const dbconn = await connectToDatabase()
  dbconn.query(`SELECT * FROM atlet WHERE ID = ${id};`,(error,result)=>{
    if (error){
      throw error
    }
    res.status(200).json({data : result})
  })
})

app.get('/currentrank',async(req,res)=>{
  const { id } = (req.query)
  const dbconn = await connectToDatabase()
  dbconn.query(`SELECT * FROM klasemenbwf WHERE ATLET_ID = ${id} ORDER BY MINGGU DESC LIMIT 1;`,(error,result)=>{
    if (error){
      throw error
    }
    res.status(200).json({data : result})
  })
})

app.get('/negara', async(req,res)=>{
  const { id } = (req.query)
  const dbcon = await connectToDatabase();
  dbcon.query(`SELECT * FROM negara where ID_ATLET = ${id};`,(error,result)=>{
    if (error){
      throw error
    }
    res.status(200).json({data : result})
  } )

})

app.get('/prestasi',async (req,res)=>{
  const dbconn = await connectToDatabase()
  dbconn.query('SELECT `NAMAKEJUR`, COUNT(`NAMAKEJUR`) AS TOTAL FROM `prestasi` GROUP BY `NAMAKEJUR` ORDER BY TOTAL DESC LIMIT 15;',(error,result)=>{
    if (error){
      throw error
    }
    res.status(200).json({data : result})
  })
})

app.get('/atletprestasi',async (req,res)=>{
  const dbconn = await connectToDatabase()
  dbconn.query('SELECT `NAMA`, COUNT(`NAMAKEJUR`) AS total_juara FROM `prestasi` GROUP BY `NAMA` ORDER BY total_juara DESC LIMIT 15;',(error,result)=>{
    if (error){
      throw error
    }
    res.status(200).json({data : result})
  })
})

const getPrestasi =  async()=>{
  const dbconn = await connectToDatabase()
  return new Promise((resolve,reject)=>{
    dbconn.query("SELECT * FROM prestasi LIMIT 150;",(error,result)=>{
      if(error){
        throw reject(error)
      }
     resolve(result)
    })
  })
}





      







app.listen(port,()=>{
    console.log("server berjalan")
})

